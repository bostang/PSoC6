var group__group__bsp__pins__capsense =
[
    [ "CYBSP_CSD_TX", "group__group__bsp__pins__capsense.html#gab8f05c019bc0eb120ca25fead2b538de", null ],
    [ "CYBSP_CINA", "group__group__bsp__pins__capsense.html#gadd4324b6eaf10be0bbd26b9598372060", null ],
    [ "CYBSP_CINB", "group__group__bsp__pins__capsense.html#ga7dbe2bacd470aab43b4476d382db91c1", null ],
    [ "CYBSP_CMOD", "group__group__bsp__pins__capsense.html#ga759e657681f3fefc466e0bd23287ab7a", null ],
    [ "CYBSP_CSD_BTN0", "group__group__bsp__pins__capsense.html#gadb772f7b52e92ec5a13c192cf878b010", null ],
    [ "CYBSP_CSD_BTN1", "group__group__bsp__pins__capsense.html#ga2f22955f575e9b43b380bc1c713e4184", null ],
    [ "CYBSP_CSD_SLD0", "group__group__bsp__pins__capsense.html#ga36e321396e39f0173bcc05314b63f72b", null ],
    [ "CYBSP_CSD_SLD1", "group__group__bsp__pins__capsense.html#gaf7f9017ffd06ebcf8ba709d858ba5411", null ],
    [ "CYBSP_CSD_SLD2", "group__group__bsp__pins__capsense.html#ga2ab777c7d3a69627e91a5c7efed6d320", null ],
    [ "CYBSP_CSD_SLD3", "group__group__bsp__pins__capsense.html#gaeb41a9ba4c9ae8316bebe53f348cc2ed", null ],
    [ "CYBSP_CSD_SLD4", "group__group__bsp__pins__capsense.html#ga0cfdc4c8461ae89960e23dfc9bc51d14", null ]
];