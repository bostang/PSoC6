var searchData=
[
  ['capsense_0',['Capsense',['../group__group__bsp__pins__capsense.html',1,'']]],
  ['communication_20pins_1',['Communication Pins',['../group__group__bsp__pins__comm.html',1,'']]]
];
